const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('adminDepartment', {
    idDepartment: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    adminDepartmentDescript: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    version: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0
    }
  }, {
    sequelize,
    tableName: 'adminDepartment',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "adminDepartment_pkey",
        unique: true,
        fields: [
          { name: "idDepartment" },
        ]
      },
    ]
  });
};
